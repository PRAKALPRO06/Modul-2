package main

import (
	"fmt"
	"strings"
)

func main() {
	var pita string
	var jumlahBunga int

	for {
		var namaBunga string
		jumlahBunga++
		fmt.Printf("Bunga %d: ", jumlahBunga)
		fmt.Scan(&namaBunga)

		if strings.ToUpper(namaBunga) == "SELESAI" {
			jumlahBunga--
			break
		}

		if pita == "" {
			pita = namaBunga
		} else {
			pita += " - " + namaBunga
		}
	}

	fmt.Println("Pita:", pita)
	fmt.Println("Bunga:", jumlahBunga)
}
