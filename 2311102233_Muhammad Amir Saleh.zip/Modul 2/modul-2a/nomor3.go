package main

import "fmt"

func volumeBola(jari float64) float64 {
	const pi = 3.1415926535
	return (4.0 / 3.0) * pi * jari * jari * jari
}

func luasPermukaanBola(jari float64) float64 {
	const pi = 3.1415926535
	return 4 * pi * jari * jari
}

func main() {
	var jejari float64

	fmt.Print("Masukkan Jejari: ")
	fmt.Scan(&jejari)

	volume := volumeBola(jejari)
	surfaceArea := luasPermukaanBola(jejari)

	fmt.Printf("Bola dengan jari-jari %.2f memiliki volume %.4f dan luas kulit %.4f\n", jejari, volume, surfaceArea)
}
