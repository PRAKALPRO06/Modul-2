package main

import (
	"fmt"
)

func konversi(celsius float64) float64 {
	return (celsius * 9 / 5) + 32
}

func main() {
	var celsius float64

	fmt.Print("Masukkan suhu dalam Celsius: ")
	fmt.Scan(&celsius)

	fahrenheit := konversi(celsius)
	fmt.Println(fahrenheit)
}
