package main

import "fmt"

func main() {
	const percobaan = 5
	expectedColors := [4]string{"merah", "kuning", "hijau", "ungu"}
	var hasilPercobaan bool = true

	// Iterasi untuk 5 kali percobaan
	for i := 0; i < percobaan; i++ {
		var warna [4]string

		fmt.Printf("Masukkan warna untuk percobaan ke-%d (pisahkan dengan spasi):\n", i+1)
		for j := 0; j < 4; j++ {
			fmt.Scan(&warna[j])
		}

		// Cek apakah urutan warna sesuai dengan yang diharapkan
		for j := 0; j < 4; j++ {
			if warna[j] != expectedColors[j] {
				hasilPercobaan = false
			}
		}
	}

	// Tampilkan hasil akhir: true jika semua percobaan berhasil, false jika ada yang gagal
	fmt.Println(hasilPercobaan)
}
