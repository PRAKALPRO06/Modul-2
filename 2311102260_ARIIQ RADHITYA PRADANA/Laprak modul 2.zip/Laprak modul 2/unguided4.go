package main

import (
	"fmt"
	"strings"
)

func main() {
	var pita string
	var count int

	// Meminta pengguna untuk memasukkan batas jumlah bunga
	var limit int
	fmt.Print("Masukkan jumlah bunga yang ingin ditambahkan: ")
	fmt.Scan(&limit)

	// Proses input bunga hingga mencapai batas jumlah bunga
	for count < limit {
		var bunga string
		fmt.Printf("Bunga %d: ", count+1)
		fmt.Scan(&bunga)

		// Cek apakah input adalah 'SELESAI'
		if strings.ToUpper(bunga) == "SELESAI" {
			break
		}

		// Penggabungan string dengan operator +
		if count == 0 {
			pita += bunga
		} else {
			pita += " - " + bunga
		}

		count++
	}

	// Tampilkan isi pita dan banyaknya bunga
	fmt.Println("Pita:", pita)
	fmt.Println("Bunga:", count)
}
