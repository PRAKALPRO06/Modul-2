package main

import (
	"fmt"
	"math"
)

func main() {
	for {
		var kantong1, kantong2 float64

		// Meminta input berat belanjaan dari user
		fmt.Print("Masukan berat belanjaan di kedua kantong: ")
		fmt.Scan(&kantong1, &kantong2)

		// Hentikan jika salah satu berat negatif
		if kantong1 < 0 || kantong2 < 0 {
			fmt.Println("Proses selesai.")
			break
		}

		// Hentikan jika total berat lebih dari 150 kg
		if kantong1+kantong2 > 150 {
			fmt.Println("Proses selesai.")
			break
		}

		// Cek apakah sepeda motor akan oleng (selisih >= 9 kg)
		oleng := math.Abs(kantong1-kantong2) >= 9
		fmt.Printf("Sepeda motor Pak Andi akan oleng: %v\n", oleng)

		// Hentikan jika salah satu kantong mencapai 9 kg atau lebih
		if kantong1 >= 9 || kantong2 >= 9 {
			fmt.Println("Proses selesai.")
			break
		}
	}
}
