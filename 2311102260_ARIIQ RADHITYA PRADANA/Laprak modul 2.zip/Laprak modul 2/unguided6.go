package main

import (
	"fmt"
)

// Fungsi untuk menghitung f(K) sesuai rumus
func calculateF(K float64) float64 {
	return (4*K + 2) * (4*K + 2) / ((4*K + 1) * (4*K + 3))
}

// Fungsi untuk menghampiri akar kuadrat dari 2
func approximateSqrt2(iterations int) float64 {
	sqrt2Approx := 1.0
	for i := 0; i < iterations; i++ {
		sqrt2Approx = (sqrt2Approx + 2/sqrt2Approx) / 2
	}
	return sqrt2Approx
}

func main() {
	// Menampilkan pesan untuk memasukkan nilai K
	var K float64
	fmt.Print("Masukkan nilai K: ")
	fmt.Scanln(&K)

	// Menghitung nilai f(K)
	fK := calculateF(K)

	// Menampilkan hasil perhitungan f(K)
	fmt.Println("Nilai f(K) =", fK)

	// Menghitung hampiran akar kuadrat dari 2
	sqrt2Approx := approximateSqrt2(10)

	// Menampilkan informasi tentang akar kuadrat dari 2
	fmt.Println("\n√2 merupakan bilangan irasional. Meskipun demikian, nilai tersebut dapat dihampiri")
	fmt.Println("dengan rumus berikut:")
	fmt.Println("√2 ≈", sqrt2Approx)
}
