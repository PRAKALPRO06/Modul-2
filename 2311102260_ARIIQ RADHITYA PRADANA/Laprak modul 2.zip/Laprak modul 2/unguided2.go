package main

import "fmt"

func main() {
	var intVals [5]int
	var charVals [3]rune

	// Input baris pertama: 5 buah integer
	fmt.Println("Masukkan 5 buah data integer (nilai antara 32 s.d. 127):")
	for i := 0; i < 5; i++ {
		fmt.Scan(&intVals[i])
	}

	// Input baris kedua: 3 buah karakter
	fmt.Println("Masukkan 3 buah karakter tanpa spasi:")
	for i := 0; i < 3; i++ {
		fmt.Scanf("%c", &charVals[i])
	}

	// Cetak representasi karakter dari integer yang diberikan
	fmt.Println("Representasi karakter dari integer:")
	for i := 0; i < 5; i++ {
		fmt.Printf("%c", intVals[i])
	}
	fmt.Println()

	// Cetak karakter setelah karakter input (berdasarkan tabel ASCII)
	fmt.Println("3 karakter setelah inputan:")
	for i := 0; i < 3; i++ {
		fmt.Printf("%c", charVals[i]+3)
	}
	fmt.Println()
}
