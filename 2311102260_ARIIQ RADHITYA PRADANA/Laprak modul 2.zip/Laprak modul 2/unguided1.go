package main

import "fmt"

func main() {
	var celsius float64

	// Input nilai temperatur dalam derajat Celsius
	fmt.Print("Masukkan temperatur dalam derajat Celsius: ")
	fmt.Scan(&celsius)

	// Menghitung suhu dalam Fahrenheit
	fahrenheit := (celsius * 9 / 5) + 32

	// Menghitung suhu dalam Reamur
	reamur := celsius * 4 / 5

	// Menghitung suhu dalam Kelvin
	kelvin := celsius + 273.15

	// Menampilkan hasil konversi
	fmt.Printf("Temperatur dalam Fahrenheit: %.2f °F\n", fahrenheit)
	fmt.Printf("Temperatur dalam Reamur: %.2f °R\n", reamur)
	fmt.Printf("Temperatur dalam Kelvin: %.2f K\n", kelvin)
}
